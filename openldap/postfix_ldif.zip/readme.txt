這說來話長, 用來讓postfix能用ldap aliase .

請利用fuck_openldap.sh 把 postfix.schema 轉成  postfix.ldif
postfix.ldif 存到 /etc/ldap/slapd.d/cn=config/cn=schema 底下
依照目錄結構將postfix命名為 cn={10}postfix.ldif
其中{10}代表該目錄第10個ldif , 因此請示情況修改
至於cn={10}postfix.ldif 內容 , 一樣需要改成{10} , 這部分請自己參考附近ldif, 跟著修正即可



Purpose
------
  Let openldap server can communcate with postfix (aliases)    

Bild postfix.ldif or use exist postfix.ldif
------
  fuck_openldap.sh  postfix.schema  postfix.ldif
  
Enable postfix.ldif
------
  1. copy postfix.ldif to  /etc/ldap/slapd.d/cn=config/cn=schema    
  2. modify "{10}" in postfix.ldif , make sure correct number in schema directory.     
  3. restart openldap server

